import React from 'react'

const StatsGrid = ({ currentGeneration, dailyGeneration, batteryLevel }) => {
  const formatPower = (watts) => {
    if (watts >= 1000) {
      return `${(watts / 1000).toFixed(1)} kW`
    }
    return `${watts.toFixed(0)} W`
  }

  const formatEnergy = (kwh) => {
    return `${kwh.toFixed(1)} kWh`
  }

  const getEfficiencyColor = (efficiency) => {
    if (efficiency >= 85) return '#4ade80'
    if (efficiency >= 70) return '#fbbf24'
    return '#ef4444'
  }

  // Calculate some derived stats
  const efficiency = Math.min(100, (currentGeneration / 5000) * 100) // Assuming 5kW max capacity
  const estimatedDailyTotal = dailyGeneration + (currentGeneration * 8 / 1000) // Rough estimate
  const carbonOffset = dailyGeneration * 0.4 // Rough estimate: 0.4 kg CO2 per kWh

  const stats = [
    {
      label: 'Current Generation',
      value: formatPower(currentGeneration),
      icon: '☀️',
      color: '#fbbf24'
    },
    {
      label: 'Daily Generation',
      value: formatEnergy(dailyGeneration),
      icon: '📊',
      color: '#10b981'
    },
    {
      label: 'Battery Level',
      value: `${batteryLevel.toFixed(0)}%`,
      icon: '🔋',
      color: batteryLevel > 60 ? '#4ade80' : batteryLevel > 30 ? '#fbbf24' : '#ef4444'
    },
    {
      label: 'System Efficiency',
      value: `${efficiency.toFixed(0)}%`,
      icon: '⚡',
      color: getEfficiencyColor(efficiency)
    },
    {
      label: 'Est. Daily Total',
      value: formatEnergy(estimatedDailyTotal),
      icon: '🎯',
      color: '#8b5cf6'
    },
    {
      label: 'CO₂ Offset Today',
      value: `${carbonOffset.toFixed(1)} kg`,
      icon: '🌱',
      color: '#059669'
    }
  ]

  return (
    <div className="stats-grid">
      {stats.map((stat, index) => (
        <div key={index} className="stat-card">
          <div style={{ fontSize: '1.5rem', marginBottom: '8px' }}>
            {stat.icon}
          </div>
          <div className="stat-value" style={{ color: stat.color }}>
            {stat.value}
          </div>
          <div className="stat-label">
            {stat.label}
          </div>
        </div>
      ))}
    </div>
  )
}

export default StatsGrid