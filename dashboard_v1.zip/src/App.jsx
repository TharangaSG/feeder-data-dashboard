import React, { useState, useEffect } from 'react'
import BatteryIndicator from './components/BatteryIndicator'
import SolarChart from './components/SolarChart'
import StatsGrid from './components/StatsGrid'

function App() {
  const [batteryLevel, setBatteryLevel] = useState(75)
  const [solarData, setSolarData] = useState([])
  const [currentGeneration, setCurrentGeneration] = useState(0)
  const [dailyGeneration, setDailyGeneration] = useState(0)

  // Simulate real-time data updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate battery level changes
      setBatteryLevel(prev => {
        const change = (Math.random() - 0.5) * 2
        return Math.max(0, Math.min(100, prev + change))
      })

      // Simulate solar generation data
      const now = new Date()
      const hour = now.getHours()
      const minute = now.getMinutes()
      
      // Solar generation follows a bell curve during daylight hours
      let generation = 0
      if (hour >= 6 && hour <= 18) {
        const timeOfDay = hour + minute / 60
        const peak = 12 // Peak at noon
        const width = 6 // Width of the bell curve
        generation = Math.max(0, 5000 * Math.exp(-Math.pow(timeOfDay - peak, 2) / (2 * Math.pow(width, 2))))
        generation += (Math.random() - 0.5) * 500 // Add some randomness
      }
      
      setCurrentGeneration(Math.max(0, generation))
      
      // Update solar data for chart
      setSolarData(prev => {
        const newData = [...prev]
        const timeLabel = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`
        
        newData.push({
          time: timeLabel,
          generation: Math.max(0, generation)
        })
        
        // Keep only last 20 data points
        if (newData.length > 20) {
          newData.shift()
        }
        
        return newData
      })
      
      // Update daily generation (cumulative)
      setDailyGeneration(prev => prev + (generation / 3600)) // Convert to kWh
    }, 5000) // Update every 5 seconds

    return () => clearInterval(interval)
  }, [])

  // Initialize with some sample data
  useEffect(() => {
    const initialData = []
    const now = new Date()
    
    for (let i = 19; i >= 0; i--) {
      const time = new Date(now.getTime() - i * 5 * 60 * 1000) // 5 minutes intervals
      const hour = time.getHours()
      const minute = time.getMinutes()
      
      let generation = 0
      if (hour >= 6 && hour <= 18) {
        const timeOfDay = hour + minute / 60
        const peak = 12
        const width = 6
        generation = Math.max(0, 5000 * Math.exp(-Math.pow(timeOfDay - peak, 2) / (2 * Math.pow(width, 2))))
        generation += (Math.random() - 0.5) * 500
      }
      
      initialData.push({
        time: `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`,
        generation: Math.max(0, generation)
      })
    }
    
    setSolarData(initialData)
    setDailyGeneration(25.6) // Sample daily generation
  }, [])

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Solar Energy Dashboard</h1>
      </div>
      
      <div className="dashboard-grid">
        <div className="widget">
          <h2>Battery Status</h2>
          <BatteryIndicator level={batteryLevel} />
        </div>
        
        <div className="widget">
          <h2>Solar Generation</h2>
          <div className="chart-container">
            <SolarChart data={solarData} />
          </div>
        </div>
      </div>
      
      <StatsGrid 
        currentGeneration={currentGeneration}
        dailyGeneration={dailyGeneration}
        batteryLevel={batteryLevel}
      />
    </div>
  )
}

export default App